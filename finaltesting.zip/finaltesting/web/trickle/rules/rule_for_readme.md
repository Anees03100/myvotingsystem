When project updates occur
- Check if README.md needs updating
- Update features list if new features are added
- Update pages list if new pages are created
- Update last updated date
- Keep information concise and accurate